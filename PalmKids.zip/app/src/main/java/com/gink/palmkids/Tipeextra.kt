package com.gink.palmkids

const val Tipeextra = "tipe"