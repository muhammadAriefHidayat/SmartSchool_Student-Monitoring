package com.gink.palmkids.dataservice

import com.gink.palmkids.model.SubjectModel


object Dataservice{
//    val lagu = listOf(
//        HomeBeritaModel("rabu, 06 September 2020","Ini adalah judul yang baik","logo","Fall"),
//        HomeBeritaModel("rabu, 06 September 2020","Ini adalah judul yang baik","logo","Fall"),
//        HomeBeritaModel("rabu, 06 September 2020","Ini adalah judul yang baik","logo","Fall"),
//        HomeBeritaModel("rabu, 06 September 2020","Ini adalah judul yang baik","logo","Fall"),
//        HomeBeritaModel("rabu, 06 September 2020","Ini adalah judul yang baik","logo","Fall"),
//        HomeBeritaModel("rabu, 06 September 2020","Ini adalah judul yang baik","logo","Fall")
//    )

    val jadwal = listOf(
        SubjectModel("07.00 - 09.00","Matematika"),
        SubjectModel("09.00 - 11.00","Seni Budaya"),
        SubjectModel("12.00 - 13.00","Fisika"),
        SubjectModel("13.00 - 15.00","Kimia"),
        SubjectModel("13.00 - 15.00","Bahasa Indonesia"),
        SubjectModel("15.00 - 17.00","Bahasa Asing"),
    )

}