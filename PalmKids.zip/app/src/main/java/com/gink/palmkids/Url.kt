package com.gink.palmkids

const val   Url = "https://elearning.palmkidslampung.sch.id"