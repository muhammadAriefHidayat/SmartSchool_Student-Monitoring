package com.gink.palmkids

const val Extra = "data"