package com.gink.palmkids

const val Newextra = "new"